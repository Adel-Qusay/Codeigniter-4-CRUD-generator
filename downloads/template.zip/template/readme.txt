#sorry! I write and speak little English. please suggest

1. copy layout folder to '{youProject}/App/Views/'

2. if you want make empty view. looking viewtemplate.php in 'example'

3. If you want to change the default site language
	3.1 copy any folder in 'Language' to '{youProject}/App/Language/'
	3.2 change the language code $defaultLocale in 'App/Config/App.php' ['en','ar','th']
	3.3 Lean Ci4 Localization in https://codeigniter4.github.io/userguide/outgoing/localization.html
