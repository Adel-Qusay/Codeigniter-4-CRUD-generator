<?php


return [
    'new' => ' إضافة مستخدم',
    'add'  => 'إضافة',
    'edit'  => 'تعديل ',
    'update' => 'تعديل ',
    'delete' => 'حذف',
    'copy' => 'Copy',
    'save'  => 'حفظ',
    'confirm' =>'تأكيد',
    'cancel'  => 'تراجع',
    'remove-title' => 'هل أنت متأكد من عملية الحذف؟',
    'remove-text' => 'لا يمكنك التراجع بعد التأكيد',
    'insert-success' => 'Data has been inserted successfully',
    'insert-error' => 'Insertion error!',
    'update-success' => 'Successfully updated',
    'update-error' => 'Update error!',
    'delete-success' => 'Successfully updated',
    'delete-error' => 'Update error!',
 
];