<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?= base_url('asset/js/jquery-3.6.0.min.js') ?>"></script>
<!-- Bootstrap 4 with Popper.js-->
<script src="<?= base_url('asset/js/bootstrap.bundle.min.js') ?>"></script>
<!-- overlayScrollbars -->
<script src="<?= base_url('asset/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js') ?>"></script>
<!-- AdminLTE App -->
<script src=" <?= base_url('asset/js/adminlte.min.js') ?>"></script>

<!-- Page Global Script -->
<!-- Toggle Button -->
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
<!-- SweetAlert2 -->
<script src="<?= base_url('asset/js/sweetalert2.all.min.js') ?>"></script>
<!-- jquery-validation -->
<script src="<?= base_url('asset/js/jquery.validate.min.js') ?>"></script>

<!-- DataTables Full Function -->
<script src="<?= base_url('asset/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?= base_url('asset/plugins/datatables/bs4/js/dataTables.bootstrap4.min.js') ?>"></script>
<script src="<?= base_url('asset/plugins/datatables/Scroller-2.0.5/js/scroller.bootstrap4.min.js') ?>"></script>

<script src="<?= base_url('asset/plugins/datatables/StateRestore/js/stateRestore.dataTables.min.js') ?>"></script>


 
<script>
    // $(function() {
    //     //first theme color setting
    //     var darkMode = "1"; // get from controller variable
    //     if (darkMode == "1") {
    //         $("#btn_darkmode").bootstrapToggle('on');
    //         $('body').addClass('dark-mode');
    //         $('.model').addClass('dark-mode');
    //     } else {
    //         $("#btn_darkmode").bootstrapToggle('off');
    //         $('body').removeClass('dark-mode');
    //         $('.model').removeClass('dark-mode');
    //     }
    //     $("#btn_darkmode").change(function() {
    //         if (this.checked) {
    //             $('body').addClass('dark-mode');
    //             $('.model').addClass('dark-mode');
    //         } else {
    //             $('body').removeClass('dark-mode');
    //             $('.model').removeClass('dark-mode');
    //         }
    //     });
    // });
</script>